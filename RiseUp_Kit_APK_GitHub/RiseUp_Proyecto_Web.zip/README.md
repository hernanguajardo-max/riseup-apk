# Rise Up - proyecto Android desde Figma

Proyecto exportado de Figma y adaptado a React + Vite + Capacitor 8. Incluye pantallas, estilos, recursos y el núcleo de optimización (voraz y First-Improvement Hill Climbing).

## Generar APK sin instalar Android Studio

Usa el archivo `RiseUp_GitHub_Actions.yml` proporcionado por separado en GitHub Actions junto con este ZIP como se describe en `INSTRUCCIONES_APK.txt`.

## Compilación local opcional

Requiere Node 22+; para compilar Android localmente hace falta Java JDK/Android SDK (pueden estar en GitHub Actions):

```
npm install
npm run typecheck
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK esperada: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notas

- La APK del flujo de GitHub Actions es una versión **debug** para pruebas e instalación manual, no una versión de publicación en Google Play.
- No requiere internet durante el uso ordinario: el HTML, CSS, JavaScript y los íconos se incluyen en la aplicación.
- No se ha realizado aquí una compilación nativa Android. Verifica la ejecución en GitHub Actions y en un teléfono.
- La interfaz mantiene el arreglo de scroll móvil y la navegación inferior del ZIP entregado.
