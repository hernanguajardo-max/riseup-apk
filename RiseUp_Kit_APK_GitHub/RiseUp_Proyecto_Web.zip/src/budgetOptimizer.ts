/**
 * Rise Up - Núcleo del modelo de optimización
 * Adaptación TypeScript del BudgetChallenge Fase 5 del proyecto original.
 * Compara una selección voraz por prioridad/costo con una búsqueda local
 * First-Improvement Hill Climbing (intercambios 1→1 y 1→2).
 */

export type BudgetCategory =
  | "Transporte"
  | "Alimentación"
  | "Entretenimiento"
  | "Ahorro"
  | "Estudios"
  | "Servicios"
  | "Otros";

export const BUDGET_CATEGORIES: BudgetCategory[] = [
  "Transporte", "Alimentación", "Entretenimiento", "Ahorro",
  "Estudios", "Servicios", "Otros",
];

export interface BudgetExpense {
  id: number;
  name: string;
  cost: number;
  priority: number;
  category: BudgetCategory;
  mandatory: boolean;
}

export interface BudgetOptimizationInput {
  budget: number;
  savingsGoalPercent: number;
  expenses: BudgetExpense[];
}

export interface ImprovementMove {
  removed: string;
  added: string[];
  previousScore: number;
  newScore: number;
}

export interface StrategyResult {
  algorithm: string;
  score: number;
  baseScore: number;
  bonus: number;
  spent: number;
  remaining: number;
  savings: number;
  entertainment: number;
  selectedIds: number[];
  valid: boolean;
  entertainmentWarning: boolean;
  elapsedMs: number;
  iterations: number;
  rounds: number;
  neighborsChecked: number;
  improvements: number;
  moves: ImprovementMove[];
}

export interface BudgetOptimizationResult {
  greedy: StrategyResult;
  hillClimbing: StrategyResult;
  improvement: number;
}

function validate(input: BudgetOptimizationInput): BudgetOptimizationInput {
  if (!input || !Array.isArray(input.expenses) || !input.expenses.length) {
    throw new Error("Debes ingresar al menos un gasto.");
  }
  if (!Number.isSafeInteger(input.budget) || input.budget <= 0) {
    throw new Error("El presupuesto debe ser un número entero mayor que cero.");
  }
  if (
    !Number.isFinite(input.savingsGoalPercent) ||
    input.savingsGoalPercent < 0 ||
    input.savingsGoalPercent > 100
  ) {
    throw new Error("La meta mínima de ahorro debe estar entre 0 y 100%.");
  }

  const ids = new Set<number>();
  const expenses = input.expenses.map((item, index): BudgetExpense => {
    if (!Number.isSafeInteger(item.id) || ids.has(item.id)) {
      throw new Error("Hay identificadores de gastos inválidos o repetidos.");
    }
    ids.add(item.id);
    if (!item.name.trim()) {
      throw new Error(`El gasto ${index + 1} necesita un nombre.`);
    }
    if (!Number.isSafeInteger(item.cost) || item.cost <= 0) {
      throw new Error(`El costo de ${item.name} debe ser un entero mayor que cero.`);
    }
    if (!Number.isSafeInteger(item.priority) || item.priority < 1 || item.priority > 10) {
      throw new Error(`La prioridad de ${item.name} debe estar entre 1 y 10.`);
    }
    if (!BUDGET_CATEGORIES.includes(item.category)) {
      throw new Error(`Selecciona una categoría válida para ${item.name}.`);
    }
    return { ...item, name: item.name.trim(), mandatory: item.mandatory === true };
  });

  const mandatoryTotal = expenses.reduce(
    (sum, item) => sum + (item.mandatory ? item.cost : 0),
    0,
  );
  if (mandatoryTotal > input.budget) {
    throw new Error(
      `Los gastos obligatorios ($${mandatoryTotal.toLocaleString("es-CL")}) ` +
      `superan el presupuesto ($${input.budget.toLocaleString("es-CL")}).`,
    );
  }
  return { ...input, expenses };
}

function evaluate(
  input: BudgetOptimizationInput,
  selection: Set<number>,
): Omit<StrategyResult, "algorithm" | "elapsedMs" | "iterations" |
  "rounds" | "neighborsChecked" | "improvements" | "moves"> {
  const selected = input.expenses.filter((item) => selection.has(item.id));
  const spent = selected.reduce((sum, item) => sum + item.cost, 0);
  const baseScore = selected.reduce((sum, item) => sum + item.priority, 0);
  const savings = selected.filter((item) => item.category === "Ahorro")
    .reduce((sum, item) => sum + item.cost, 0);
  const entertainment = selected.filter((item) => item.category === "Entretenimiento")
    .reduce((sum, item) => sum + item.cost, 0);
  // Mismo puntaje Z del proyecto Fase 5: +5 si se alcanza la meta de ahorro.
  const bonus = savings >= (input.budget * input.savingsGoalPercent) / 100 ? 5 : 0;
  return {
    selectedIds: selected.map((item) => item.id),
    spent,
    remaining: input.budget - spent,
    savings,
    entertainment,
    baseScore,
    bonus,
    score: baseScore + bonus,
    valid: spent <= input.budget && input.expenses.every((item) => !item.mandatory || selection.has(item.id)),
    entertainmentWarning: entertainment > input.budget * 0.2,
  };
}

function solveGreedy(input: BudgetOptimizationInput): StrategyResult {
  const started = performance.now();
  const selected = new Set<number>();
  let remaining = input.budget;

  for (const item of input.expenses) {
    if (item.mandatory) {
      selected.add(item.id);
      remaining -= item.cost;
    }
  }

  const optional = input.expenses.filter((item) => !item.mandatory);
  // Densidad = prioridad/costo. Criterios de empate idénticos al núcleo original.
  optional.sort((a, b) =>
    (b.priority * a.cost - a.priority * b.cost) ||
    (b.priority - a.priority) ||
    (a.cost - b.cost) ||
    (a.id - b.id),
  );
  for (const item of optional) {
    if (item.cost <= remaining) {
      selected.add(item.id);
      remaining -= item.cost;
    }
  }

  return {
    ...evaluate(input, selected),
    algorithm: "Voraz (prioridad/costo)",
    elapsedMs: performance.now() - started,
    iterations: input.expenses.length + optional.length,
    rounds: 0,
    neighborsChecked: 0,
    improvements: 0,
    moves: [],
  };
}

function solveHillClimbing(input: BudgetOptimizationInput): StrategyResult {
  const started = performance.now();
  const initial = solveGreedy(input);
  const selection = new Set(initial.selectedIds);
  let spent = initial.spent;
  let baseScore = initial.baseScore;
  let savings = initial.savings;
  let rounds = 0;
  let neighborsChecked = 0;
  const moves: ImprovementMove[] = [];
  const threshold = (input.budget * input.savingsGoalPercent) / 100;
  const savingsBonus = (amount: number) => amount >= threshold ? 5 : 0;

  function tryMove(removed: BudgetExpense, added: BudgetExpense[]): boolean {
    neighborsChecked++;
    const newSpent = spent - removed.cost + added.reduce((sum, item) => sum + item.cost, 0);
    if (newSpent > input.budget) return false;
    const newBaseScore = baseScore - removed.priority +
      added.reduce((sum, item) => sum + item.priority, 0);
    const newSavings = savings - (removed.category === "Ahorro" ? removed.cost : 0) +
      added.reduce((sum, item) => sum + (item.category === "Ahorro" ? item.cost : 0), 0);
    const previousScore = baseScore + savingsBonus(savings);
    const nextScore = newBaseScore + savingsBonus(newSavings);
    if (nextScore <= previousScore) return false;

    selection.delete(removed.id);
    for (const item of added) selection.add(item.id);
    spent = newSpent;
    baseScore = newBaseScore;
    savings = newSavings;
    moves.push({
      removed: removed.name,
      added: added.map((item) => item.name),
      previousScore,
      newScore: nextScore,
    });
    return true;
  }

  // First-Improvement: acepta el primer vecino que mejora Z y reinicia búsqueda.
  while (true) {
    rounds++;
    const fundedOptional = input.expenses.filter((item) => selection.has(item.id) && !item.mandatory);
    const excluded = input.expenses.filter((item) => !selection.has(item.id));
    let changed = false;

    search:
    for (const removed of fundedOptional) {
      for (const added of excluded) {
        if (tryMove(removed, [added])) {
          changed = true;
          break search;
        }
      }
      for (let a = 0; a < excluded.length; a++) {
        for (let b = a + 1; b < excluded.length; b++) {
          if (tryMove(removed, [excluded[a], excluded[b]])) {
            changed = true;
            break search;
          }
        }
      }
    }
    if (!changed) break;
  }

  return {
    ...evaluate(input, selection),
    algorithm: "Voraz + Hill Climbing (First-Improvement)",
    elapsedMs: performance.now() - started,
    iterations: initial.iterations,
    rounds,
    neighborsChecked,
    improvements: moves.length,
    moves,
  };
}

/** Ejecuta ambos métodos usando las mismas entradas. No simula resultados. */
export async function executeBudgetOptimization(
  rawInput: BudgetOptimizationInput,
): Promise<BudgetOptimizationResult> {
  const input = validate(rawInput);
  const greedy = solveGreedy(input);
  const hillClimbing = solveHillClimbing(input);
  return {
    greedy,
    hillClimbing,
    improvement: hillClimbing.score - greedy.score,
  };
}
