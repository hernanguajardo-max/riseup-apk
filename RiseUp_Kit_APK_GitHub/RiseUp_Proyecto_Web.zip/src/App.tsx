import { useState, type FormEvent, type ReactNode } from "react";
import {
  BUDGET_CATEGORIES,
  executeBudgetOptimization,
  type BudgetCategory,
  type BudgetExpense,
  type BudgetOptimizationInput,
  type BudgetOptimizationResult,
  type StrategyResult,
} from "./budgetOptimizer";

const assetPathPrefix = "/assets";

type Screen = "home" | "expenses" | "results";
type ExpenseDraft = Omit<BudgetExpense, "cost" | "priority"> & {
  cost: string;
  priority: string;
};

const initialExpenses: ExpenseDraft[] = [
  { id: 1, name: "Pase Escolar", cost: "15000", priority: "10", category: "Transporte", mandatory: true },
  { id: 2, name: "Supermercado", cost: "45000", priority: "9", category: "Alimentación", mandatory: true },
  { id: 3, name: "Material de estudio", cost: "20000", priority: "9", category: "Estudios", mandatory: false },
  { id: 4, name: "Plan móvil", cost: "10000", priority: "8", category: "Servicios", mandatory: false },
  { id: 5, name: "Fotocopias", cost: "5000", priority: "6", category: "Estudios", mandatory: false },
  { id: 6, name: "Ocio y salidas", cost: "25000", priority: "3", category: "Entretenimiento", mandatory: false },
];

function digitsOnly(value: string) {
  return value.replace(/\D/g, "");
}

function formatAmount(value: string) {
  if (!digitsOnly(value)) return "";
  const amount = Number(digitsOnly(value));
  return Number.isFinite(amount) ? amount.toLocaleString("es-CL") : "";
}

function pesos(value: number) {
  return `$${value.toLocaleString("es-CL")}`;
}

function rango(score: number) {
  return score >= 35 ? "Oro" : score >= 20 ? "Plata" : "Bronce";
}

function AppHeader({
  step,
  title,
  description,
}: {
  step: string;
  title: string;
  description: string;
}) {
  return (
    <>
      <header className="plan-header">
        <strong>MODELO DE OPTIMIZACIÓN</strong>
        <span>{step} / 03</span>
      </header>
      <div className="page-heading">
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
    </>
  );
}

function BottomNavigation({
  screen,
  onNavigate,
}: {
  screen: Screen;
  onNavigate: (screen: Screen) => void;
}) {
  const items: Array<{ screen: Screen; label: string; icon: string }> = [
    { screen: "home", label: "Inicio", icon: "a9cea.svg" },
    { screen: "expenses", label: "Gastos", icon: "7fdf4.svg" },
    { screen: "results", label: "Resumen", icon: "1a30d.svg" },
  ];

  return (
    <nav className="bottom-navigation" aria-label="Navegación principal">
      {items.map((item) => (
        <button
          className={screen === item.screen ? "nav-item active" : "nav-item"}
          key={item.screen}
          onClick={() => onNavigate(item.screen)}
          type="button"
        >
          <img alt="" height="19" src={`${assetPathPrefix}/${item.icon}`} width="19" />
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

function PageShell({
  children,
  screen,
  onNavigate,
}: {
  children: ReactNode;
  screen: Screen;
  onNavigate: (screen: Screen) => void;
}) {
  return (
    <main
      className="app-shell"
      style={{
        height: "100dvh",
        maxHeight: "100dvh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        minHeight: 0,
      }}
    >
      <section
        className="page-content"
        style={{
          flex: "1 1 auto",
          minHeight: 0,
          minWidth: 0,
          overflowY: "auto",
          overflowX: "hidden",
          WebkitOverflowScrolling: "touch",
          overscrollBehaviorY: "contain",
          touchAction: "pan-y",
          paddingBottom: 16,
        }}
      >
        {children}
      </section>
      <div style={{ flexShrink: 0, position: "relative", zIndex: 1 }}>
        <BottomNavigation onNavigate={onNavigate} screen={screen} />
      </div>
    </main>
  );
}

function HomeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return (
    <PageShell onNavigate={onNavigate} screen="home">
      <AppHeader
        description="Organiza tus gastos según tu presupuesto y sus prioridades."
        step="01"
        title="Optimiza tu presupuesto"
      />
      <section className="intro-card">
        <span>PASO SIGUIENTE</span>
        <h2>Define tus gastos</h2>
        <p>Ingresa el monto disponible y la importancia de cada gasto para preparar el modelo.</p>
      </section>
      <button className="primary-button home-action" onClick={() => onNavigate("expenses")}>
        Comenzar
      </button>
    </PageShell>
  );
}

function StrategyCard({
  strategy,
  expenses,
  heading,
}: {
  strategy: StrategyResult;
  expenses: BudgetExpense[];
  heading: string;
}) {
  const selected = expenses.filter((expense) => strategy.selectedIds.includes(expense.id));
  return (
    <section className="result-card">
      <span>{heading}</span>
      <h2>{strategy.score} puntos · {rango(strategy.score)}</h2>
      <p><strong>Presupuesto asignado:</strong> {pesos(strategy.spent)}</p>
      <p><strong>Saldo disponible:</strong> {pesos(strategy.remaining)}</p>
      <p><strong>Ahorro seleccionado:</strong> {pesos(strategy.savings)}</p>
      <p><strong>Bonificación por ahorro:</strong> +{strategy.bonus} puntos</p>
      <p><strong>Gastos seleccionados:</strong> {selected.length} de {expenses.length}</p>
      <p><strong>Tiempo de ejecución:</strong> {strategy.elapsedMs.toFixed(3)} ms</p>
      <p><strong>Solución válida:</strong> {strategy.valid ? "Sí" : "No"}</p>
      <details>
        <summary>Ver gastos financiados</summary>
        <ul>
          {selected.map((expense) => (
            <li key={expense.id}>{expense.name}: {pesos(expense.cost)}</li>
          ))}
        </ul>
      </details>
      {strategy.entertainmentWarning && (
        <p>Advertencia: entretenimiento supera el 20% recomendado del presupuesto.</p>
      )}
      {strategy.rounds > 0 && (
        <p>
          <strong>Hill Climbing:</strong> {strategy.rounds} rondas, {strategy.neighborsChecked}
          {" "}vecinos evaluados y {strategy.improvements} mejoras.
        </p>
      )}
    </section>
  );
}

function ResultsScreen({
  input,
  result,
  error,
  onNavigate,
}: {
  input: BudgetOptimizationInput | null;
  result: BudgetOptimizationResult | null;
  error: string | null;
  onNavigate: (screen: Screen) => void;
}) {
  return (
    <PageShell onNavigate={onNavigate} screen="results">
      <AppHeader
        description="Comparación real de las estrategias de optimización."
        step="03"
        title="Resultados de Optimización"
      />
      {result && input ? (
        <>
          <StrategyCard strategy={result.greedy} expenses={input.expenses} heading="ESTRATEGIA 1 · VORAZ" />
          <StrategyCard strategy={result.hillClimbing} expenses={input.expenses} heading="ESTRATEGIA 2 · HILL CLIMBING" />
          <section className="result-card">
            <span>COMPARACIÓN DEL LABORATORIO 9</span>
            <h2>
              {result.improvement > 0
                ? `Hill Climbing mejoró ${result.improvement} puntos`
                : "Ambos métodos obtuvieron el mismo puntaje"}
            </h2>
            {result.hillClimbing.moves.length > 0 ? (
              <ol>
                {result.hillClimbing.moves.map((move, index) => (
                  <li key={index}>
                    Retirar {move.removed}; incorporar {move.added.join(" y ")}. Z: {move.previousScore} → {move.newScore}.
                  </li>
                ))}
              </ol>
            ) : (
              <p>No se encontraron intercambios 1→1 o 1→2 que mejoraran la solución voraz.</p>
            )}
            <p>Hill Climbing encuentra un óptimo local, no necesariamente el máximo global.</p>
          </section>
        </>
      ) : (
        <section className="result-card">
          <span>{input ? "DATOS RECOPILADOS" : "SIN CÁLCULO"}</span>
          <h2>{error ? "No se pudo calcular" : "Aún no hay resultados"}</h2>
          <p>{error ?? "Completa los gastos y presiona Calcular para ejecutar ambos algoritmos."}</p>
          {input && <p className="payload-summary">Presupuesto: {pesos(input.budget)} · {input.expenses.length} gastos</p>}
        </section>
      )}
      <button className="secondary-button" onClick={() => onNavigate("expenses")}>Modificar entradas</button>
    </PageShell>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("expenses");
  const [budget, setBudget] = useState("100000");
  const [savingsGoalPercent, setSavingsGoalPercent] = useState("10");
  const [expenses, setExpenses] = useState<ExpenseDraft[]>(initialExpenses);
  const [submittedInput, setSubmittedInput] = useState<BudgetOptimizationInput | null>(null);
  const [result, setResult] = useState<BudgetOptimizationResult | null>(null);
  const [integrationError, setIntegrationError] = useState<string | null>(null);
  const [calculating, setCalculating] = useState(false);

  function invalidateResult() {
    setSubmittedInput(null);
    setResult(null);
    setIntegrationError(null);
  }

  function updateExpense(id: number, patch: Partial<ExpenseDraft>) {
    setExpenses((current) => current.map((expense) =>
      expense.id === id ? { ...expense, ...patch } : expense,
    ));
    invalidateResult();
  }

  function addExpense() {
    setExpenses((current) => [
      ...current,
      {
        id: Math.max(0, ...current.map((expense) => expense.id)) + 1,
        name: "Nuevo gasto",
        cost: "10000",
        priority: "5",
        category: "Otros",
        mandatory: false,
      },
    ]);
    invalidateResult();
  }

  function removeExpense(id: number) {
    setExpenses((current) => current.filter((expense) => expense.id !== id));
    invalidateResult();
  }

  async function calculate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input: BudgetOptimizationInput = {
      budget: Number(budget),
      savingsGoalPercent: Number(savingsGoalPercent),
      expenses: expenses.map((expense) => ({
        id: expense.id,
        name: expense.name.trim(),
        cost: Number(expense.cost),
        priority: Number(expense.priority),
        category: expense.category,
        mandatory: expense.mandatory,
      })),
    };

    setSubmittedInput(input);
    setResult(null);
    setIntegrationError(null);
    setCalculating(true);
    try {
      const optimizationResult = await executeBudgetOptimization(input);
      setResult(optimizationResult);
    } catch (error) {
      setIntegrationError(error instanceof Error ? error.message : "No fue posible ejecutar el algoritmo.");
    } finally {
      setCalculating(false);
      setScreen("results");
    }
  }

  if (screen === "home") return <HomeScreen onNavigate={setScreen} />;
  if (screen === "results") {
    return (
      <ResultsScreen
        error={integrationError}
        input={submittedInput}
        onNavigate={setScreen}
        result={result}
      />
    );
  }

  return (
    <PageShell onNavigate={setScreen} screen="expenses">
      <form className="expenses-form" onSubmit={calculate}>
        <AppHeader
          description="Define el límite y la importancia de cada gasto."
          step="02"
          title="Entradas del Modelo"
        />

        <label className="budget-card">
          <span>Presupuesto Total (M)</span>
          <div className="budget-input-wrap">
            <b aria-hidden="true">$</b>
            <input
              aria-label="Presupuesto total mensual"
              inputMode="numeric"
              onChange={(event) => {
                setBudget(digitsOnly(event.target.value));
                invalidateResult();
              }}
              required
              value={formatAmount(budget)}
            />
            <small>mensuales</small>
          </div>
        </label>

        <details style={{ margin: "12px 0", fontSize: 12 }}>
          <summary style={{ cursor: "pointer", fontWeight: 700 }}>
            Configurar meta de ahorro
          </summary>
          <label style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 8 }}>
            <span>Meta mínima de ahorro (%)</span>
            <input
              aria-label="Meta mínima de ahorro en porcentaje"
              type="number"
              min="0"
              max="100"
              step="1"
              required
              style={{ width: 62 }}
              value={savingsGoalPercent}
              onChange={(event) => {
                setSavingsGoalPercent(event.target.value);
                invalidateResult();
              }}
            />
          </label>
          <p>Se suman 5 puntos al puntaje Z si los gastos de categoría Ahorro alcanzan la meta.</p>
        </details>

        <section className="expenses-section">
          <h2>Gastos a evaluar · {expenses.length}</h2>
          <div className="expense-grid">
            {expenses.map((expense, index) => (
              <article className="expense-card" key={expense.id}>
                <div className="expense-name-row">
                  <input
                    aria-label={`Nombre del gasto ${index + 1}`}
                    className="expense-name"
                    maxLength={40}
                    onChange={(event) => updateExpense(expense.id, { name: event.target.value })}
                    required
                    value={expense.name}
                  />
                  <span>{String(index + 1).padStart(2, "0")}</span>
                </div>
                <div className="expense-values">
                  <label>
                    <span>Costo ($)</span>
                    <input
                      aria-label={`Costo de ${expense.name}`}
                      inputMode="numeric"
                      onChange={(event) => updateExpense(expense.id, { cost: digitsOnly(event.target.value) })}
                      required
                      value={formatAmount(expense.cost)}
                    />
                  </label>
                  <label>
                    <span>Prioridad (1-10)</span>
                    <input
                      aria-label={`Prioridad de ${expense.name}`}
                      max="10"
                      min="1"
                      onChange={(event) => updateExpense(expense.id, { priority: event.target.value })}
                      required
                      type="number"
                      value={expense.priority}
                    />
                  </label>
                </div>
                <details style={{ marginTop: 6, fontSize: 12 }}>
                  <summary style={{ cursor: "pointer" }}>Categoría y obligatoriedad</summary>
                  <label style={{ display: "block", marginTop: 7 }}>
                    Categoría:{" "}
                    <select
                      aria-label={`Categoría de ${expense.name}`}
                      value={expense.category}
                      onChange={(event) => updateExpense(expense.id, { category: event.target.value as BudgetCategory })}
                    >
                      {BUDGET_CATEGORIES.map((category) => (
                        <option value={category} key={category}>{category}</option>
                      ))}
                    </select>
                  </label>
                  <label style={{ display: "flex", gap: 7, alignItems: "center", marginTop: 7 }}>
                    <input
                      type="checkbox"
                      checked={expense.mandatory}
                      onChange={(event) => updateExpense(expense.id, { mandatory: event.target.checked })}
                    />
                    Gasto obligatorio (se financia primero)
                  </label>
                  <button type="button" onClick={() => removeExpense(expense.id)} style={{ marginTop: 9 }}>
                    Eliminar gasto
                  </button>
                </details>
              </article>
            ))}
          </div>
          <button type="button" onClick={addExpense} style={{ marginTop: 12, width: "100%", padding: 10 }}>
            + Agregar nuevo gasto
          </button>
        </section>

        <p className="reference-note">
          Ejemplo académico · los gastos obligatorios se financian primero; después se optimizan los opcionales.
        </p>
        <button className="primary-button" type="submit" disabled={calculating}>
          {calculating ? "Calculando..." : "Calcular"}
        </button>
      </form>
    </PageShell>
  );
}
