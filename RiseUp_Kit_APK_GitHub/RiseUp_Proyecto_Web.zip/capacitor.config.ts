import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "cl.riseup.presupuesto",
  appName: "Rise Up",
  webDir: "dist",
};

export default config;
