# Rise Up — versión original HTML para APK

Este proyecto se creó a partir de `index (2)(1).html` y conserva su diseño:
**Bienvenida → Gastos → Resultados**, colores, botones, tarjetas y datos de ejemplo.

## Algoritmos

1. **Heurística Voraz, mochila 0/1**. Reserva gastos obligatorios, ordena opcionales
   por densidad = prioridad / costo y financia ítems completos si caben en el
   presupuesto. Muestra puntuación Z, saldo, evaluaciones e iteraciones.
2. **Búsqueda local First-Improvement**. Parte de la solución voraz y prueba
   adiciones 0→1, intercambios 1→1 y 1→2; acepta un vecino solo cuando mejora
   la función objetivo sin exceder el presupuesto. No es una simulación.
3. **Función objetivo**: suma de prioridades de los gastos seleccionados, y
   un bono de 5 puntos si hay meta positiva de ahorro y se alcanza.

La interfaz original solicita la meta en pesos; el algoritmo la convierte a
fracción de M (ejemplo: $15.000 de $100.000 corresponde a 0,15).

## Diseño

El diseño se preserva. Solo se añade una adaptación de tamaño para que la
pantalla del móvil no recorte el contenido ni la navegación inferior.

## GitHub Actions

El contenido de este ZIP funciona con el workflow preexistente `Generar APK Rise Up`:
se espera `RiseUp_Kit_APK_GitHub/RiseUp_Proyecto_Web.zip` en el repositorio.

Para no reemplazar la versión Figma, usar el workflow separado
`generar-apk-html-original.yml` proporcionado junto al proyecto, que espera
`RiseUp_Kit_APK_GitHub/RiseUp_HTML_Original_Para_APK.zip`.

El ID Android de esta versión es `cl.riseup.htmloriginal`, distinto del APK Figma
(`cl.riseup.presupuesto`). Puede instalarse en paralelo.

## Compilar desde el código

```
npm install --no-audit --no-fund
npm run typecheck
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

La APK no está dentro de este ZIP; Android se compila en GitHub Actions.
