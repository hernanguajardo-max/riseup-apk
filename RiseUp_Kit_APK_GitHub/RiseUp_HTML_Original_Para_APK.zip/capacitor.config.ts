import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'cl.riseup.htmloriginal',
  appName: 'Rise Up Original',
  webDir: 'dist',
};

export default config;
