import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/i);
if (!match) throw new Error('No se encontró JavaScript en el HTML.');
new vm.Script(match[1], { filename: 'riseup-inline.js' });
if (!html.includes('correrVoraz') || !html.includes('correrHillClimbing')) {
  throw new Error('No se encontraron los dos algoritmos.');
}
if (html.includes('mejorZ += 1')) throw new Error('Se encontró el Hill Climbing simulado.');
console.log('OK: estructura HTML, sintaxis JavaScript y presencia de algoritmos.');
