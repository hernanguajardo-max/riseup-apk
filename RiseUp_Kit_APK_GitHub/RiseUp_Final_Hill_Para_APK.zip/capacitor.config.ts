import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'cl.riseup.usuariohillfinal', appName: 'Rise Up', webDir: 'dist' };
export default config;
