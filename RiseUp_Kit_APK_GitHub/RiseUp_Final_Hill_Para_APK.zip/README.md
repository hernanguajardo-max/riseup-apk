# Rise Up — versión de usuario con Hill Climbing único

Esta entrega aplica la decisión del último laboratorio: **se selecciona un solo algoritmo** para la aplicación, Hill Climbing First-Improvement. No se ejecuta ni incluye la heurística Voraz en esta versión.

## Interfaz
- Diseño verde de Rise Up, con tres pantallas: Inicio, Gastos y Mi plan.
- Presupuesto y meta inicialmente vacíos; los números grises son ejemplos (`placeholder`).
- Dos formularios de gastos inicialmente vacíos, más botón para agregar otros.
- Nombre, costo, importancia 1–10, categoría y gastos indispensables.
- Cuatro categorías: Transporte, Alimentación, Entretenimiento y Ahorro.
- Resumen agrupado por categoría, gastos postergados, saldo, ahorro, nivel Bronce/Plata/Oro.
- Sin comparaciones algorítmicas ni resultados matemáticos en la pantalla del usuario.

## Algoritmo elegido
- **First-Improvement Hill Climbing**. Empieza con todos los gastos marcados indispensables, sin usar una solución Voraz.
- Recorre vecinos por orden fijo: adición 0→1, intercambio 1→1, intercambio 1→2. Acepta de inmediato la primera solución factible cuyo puntaje Z sea estrictamente mayor y reinicia hasta que no encuentre mejoras en el vecindario.
- Presupuesto y gastos indispensables son restricciones duras.
- Objetivo Z interno: suma de prioridades financiadas más 5 si se financia ahorro por al menos 10 % del presupuesto o la meta del usuario, si es mayor.
- El entretenimiento superior a 20 % genera una advertencia (no bloqueo).
- Bronce, Plata y Oro se calculan como proporción de las prioridades cubiertas; los cortes son una convención de implementación, porque el informe no los define.
- Hill Climbing es una heurística que encuentra óptimos locales de ese vecindario, no garantiza óptimo global.

## Diferencia con informe histórico
El informe del 16-11-2026 documenta la comparación académica de Voraz y Hill. Esta versión final implementa únicamente Hill, siguiendo la indicación posterior de seleccionar uno. Como Hill ya no parte de Voraz, no se esperan los mismos puntajes de las tablas históricas. Para el informe final conviene documentar este cambio de estrategia e indicar con qué criterio se escogió Hill (calidad de la solución, puntaje Z); Voraz puede ser más rápido en tiempo de ejecución.

## Compilar en GitHub Actions
1. Sube `RiseUp_Final_Hill_Para_APK.zip` sin descomprimir a `RiseUp_Kit_APK_GitHub/`.
2. Sube `generar-apk-hill-final.yml` a `.github/workflows/`.
3. Ejecuta `Generar APK Rise Up Final Hill` desde Actions, rama `main`.
4. Descarga `RiseUp-Final-Hill-APK-Android` de Artifacts.

App ID `cl.riseup.usuariohillfinal` permite instalarla sin reemplazar otras versiones.
