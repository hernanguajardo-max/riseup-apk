import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/i)?.[1];
if(!js)throw new Error('Script no encontrado');
new vm.Script(js,{filename:'riseup-final-hill.js'});
for(const func of ['correrHillClimbing','evaluarSolucion','validarEntrada','nivelGamificado']){
 if(!js.includes('function '+func+'('))throw new Error('Falta '+func);
}
for(const remove of ['function correrVoraz(', 'detallesAcademicos','acVoraz']){
 if(html.includes(remove))throw new Error('No se eliminó '+remove);
}
for(const id of ['screen1','screen2','screen3','itemsList','resSaldo','resSeleccionados']){
 if(!html.includes('id="'+id+'"'))throw new Error('Falta pantalla/campo '+id);
}
console.log('Verificación: Hill Climbing único, HTML y navegación presentes.');
