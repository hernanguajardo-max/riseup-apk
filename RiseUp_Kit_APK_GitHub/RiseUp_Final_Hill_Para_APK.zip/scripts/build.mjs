import { mkdirSync, copyFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root=dirname(dirname(fileURLToPath(import.meta.url)));
mkdirSync(join(root,'dist'),{recursive:true});
copyFileSync(join(root,'index.html'),join(root,'dist','index.html'));
console.log('Interfaz lista en dist/index.html');
